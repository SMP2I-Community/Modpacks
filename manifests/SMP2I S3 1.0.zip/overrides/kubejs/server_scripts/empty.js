// Visit the wiki for more info - https://kubejs.com/
ServerEvents.recipes(event => {







    
})